# 2019-12-16 上午

## 元素类型part

### html角度对标签分类：单标签、双标签

#### 元素嵌套
- 块状元素一般作为父元素出现 ，可嵌套 块元素 或 内联元素
- 内联元素的子元素尽量使内联元素
    + 比如不能 <a><p>大错特错</p></a>
- p标签 有些特殊
    + p 标签不能进行 p 嵌套，浏览器会让嵌套p标签并列显示，会影响排版
    + p 嵌套的标签  不能是 h1-h6
- 内联元素即便转成了块元素，也不能来嵌套块元素
    + 比如 <span><div>span转层块，也不可以包着div</div></span>


### 标签还可分类为：置换元素、非置换元素

### css角度对标签分类：（显示分类）
- 第一种分类
    + 块状元素
    + 内联元素（行内元素）
    + 可变元素

- 第二种分类（不常用）
    + 块状元素
    + 内联元素
    + 内联块元素

#### 各元素类型的特点
- **块状元素的特点**
    1：能直接设置大小。
    2：独占一行，自上而下排列
    3: 通常作为其他元素的容器
    4：在页面中以矩形区域显示

- **内联元素的特点**
    + 内联元素text-align:center;时，整个标签都居中了；
    1：不能直接设置大小
    2：在一行内逐个排列，不会独占一行
    3: 大小是被内容撑开的，最小单位也是矩形。
    4: 给内联元素设置 margin  padding的时候，个别属性（padding-top/bottom  margin-top/bottom）不能正确显示。

- **可变元素**
    + 根据上下文的需求，来确定元素生成块或者是内联。<button></button>

#### 各类型元素所涉及标签
- **块状元素**
```txt
    div -最常用的块级元素
    dl - 和dt-dd 搭配使用的块级元素
    form - 交互表单
    h1 -h6- 大标题
    hr - 水平分隔线
    ol – 有序列表
    p - 段落
    ul - 无序列表
    li                              -----display:list-item;
    fieldset - 表单字段集
    colgroup-col - 表单列分组元素
    table-tr-td  表格及行-单元格
```
- **内联元素**
```txt
    a –超链接（锚点）                               
    b - 粗体(不推荐) 
    br - 换行                             
    i - 斜体
    em - 强调                             
    img - 图片         -----display:inline  但是支持宽高,默认有                      下边距，变成block就没有了
    input - 输入框               -----display:inline-block;
    label - 表单标签                  
    span - 常用内联容器，定义文本内区块
    strong - 粗体强调
    sub - 下标   
    sup - 上标
    textarea - 多行文本输入框    -----display:inline-block;
    u - 下划线
    select - 项目选择(下拉列表)     -----display:inline-block;
```


### 元素类型的转换
- display属性：检索或者设置 元素生成的盒模型类型。

    属性值：
    1: display:block;   将元素转成块状元素（拥有块状元素特点）
    2: display:inline    将元素转成内联元素
    3: display:list-item;  li的display的默认值。
    4: display:none     将元素隐藏，不占据空间。
    5：display:inline-block   
        a：行内块元素布局：默认能添加大小，横向排列
        b：inline-block与vertical-align的用法（下面有方法、示例）

#### inline与inline-block引起的空白间距的问题
- 产生原因：回车--->空白间隔
- 目前解决方法：三种
    + 第一种：将相关标签写在一行，消除换行符
    + 第二种：加浮动，使之转化成为block元素（可能会影响页面布局）
    + 第三种：直接改变元素类型---display:block;

#### 导航示例
- display 比 float用的多（float有可能影响布局）
- 观察 哪些属性改变化了，哪些没有变
```html
<style>
    @charset 'utf-8';

    *{margin: 0;padding: 0;}
    ul,li,ol{list-style: none;}
    a,u{text-decoration: none;}

    .nav1{width:600px;margin:50px auto;}


    /* 导航条1 */
    .nav1{
        height:40px;
        border-bottom: 1px solid #afafaf;
    }
            /* 悬浮效果 第一种代码 */
    .nav1 li{
        float: left;
        padding-top: 4px;
    }
    .nav1 li a{
        display:block;
        height: 35px;
        line-height:35px;
        background: #f9f9f9;
        padding:0 14px;
        border:1px solid #d8d8d8;
        border-bottom: 0;
        color: #a9adae;
        font-size: 12px;
        margin: 0 5px;
    }
    .nav1 li a:hover{
        height: 39px;
        color: #80857f;
        border-color: #afafaf;
    }
    .nav1 li:hover{
        padding-top: 0;
    }

        /* 悬浮效果 第二种代码 */
    .nav1 li{
        float: left;
        /* padding-top: 4px; */
    }
    .nav1 li a{
        display:block;
        height: 35px;
        line-height:35px;
        background: #f9f9f9;
        padding:0 14px;
        border:1px solid #d8d8d8;
        border-bottom: 0;
        color: #a9adae;
        font-size: 12px;
        margin:4px 5px 0
    }
    .nav1 li a:hover{
        height: 39px;
        color: #80857f;
        border-color: #afafaf;
        margin-top: 0px;
    }
</style>

<!-- 导航条1 -->
     <ul class="nav1">
        <li><a href="#">tab one</a></li>
        <li><a href="#">tab two</a></li>
        <li><a href="#">tab three</a></li>
        <li><a href="#">tab four</a></li>
        <li><a href="#">tab five</a></li>
    </ul>
```



# 2019-12-16 下午

## 元素垂直上下居中part

### vertical-align:; 属性介绍
- 属性值
    + top         -----顶线
    + middle      -----中线
    + baseline    -----基线(X的最底端)
    + bottom      -----底线

### 元素在父元素里**垂直上下居中**的方法
    (1) 父元素 text-align:center;（确定目标子元素左右居中，此处margin：0 auto；没用）
    (2) 目标子元素 display:inline-block; 且 vertical-align:middle;
    (3) 子元素后面添加同级元素 span  给span设置{ (span作为辅助元素，配和目标子元素确定中线)
        display:inline-block;
        height:100%;
        width:0;
        vertical-align: middle;}

#### 示例
```html
<style>
    .out-side{
           width: 500px;
           height: 300px;
           background: teal;

           text-align: center;/*条件*/
       }
        .out-side .v_align{
            width: 100px;
            height: 100px;
            background: tomato;

            vertical-align: middle;/*条件*/
            display: inline-block;/*条件*/
        }
        .out-side span{
            display: inline-block;/*条件*/
            
            width: 0;
            height: 100%;/*重要*/

            vertical-align: middle;/*条件*/
        }
</style>

<div class="out-side">
       <div class="v_align">其与右边span的中线为标准线</div><span></span>
   </div>

```

# 面试题（Word里面）


## 定位part
- 需要注意一个点，用定位的话会对一些属性造成影响，然后我就发现，用了定位，float和margin就不能正常使用了，把float：none；清浮动一下，margin：0 auto；就能够与position共存了。

### 定位属性 position:;
（1）static   默认值      

（2）absolute  :  绝对定位
    + 相对于**已经有定位**属性的父元素的绝对定位；
    + 如果没有父元素或者是父元素没有定位的情况下，根据**文档定位**，即元素相对于根元素定位（即html元素）；
    + 添加绝对定位的元素，是不占据空间，**完全**脱离文档流；
    + 通过left   right   top    bottom 进行位置的变化；
    + 绝对定位时，浮动不起作用。

    + 绝对定位元素在没有定义宽度的情况下，宽度由元素里面的内容决定，效果和用float方法一样。

（3）relative  : 相对定位
+ 相对于自己默认位置的相对定位。
    - 常用 top、left 来确定位置，如果非要用right、bottom的话，其实：top:-100px = bottom:100px; left:-100px = right:100px;
+ 占据空间，但不破坏文档流。

（4）fixed  :   固定定位：
    参照物：浏览器窗口

（5）stikey   粘性定位。
    position:relative  和 position:fixed的结合。
    当元素超出屏幕以外运行的是：position:fixed;  反之应用的时候position:relative;
    （可以做出“吸顶”效果哦）


### 参照物
- 绝对定位参照物：有定位属性的父元素。
- 相对定位的参照物：自身默认的位置。

- 包含块的设置
    给作为参照物的父元素添加：position:relative;
    给要做定位的元素添加：position:absolute;

### fixed的用法、示例

#### 元素在浏览器窗口左右上下居中
- 麻烦的方法
    position:fixed;
    left:50%;
    top:50%;
    margin-left:-宽度的一半;
    margin-top:-高度的一半;

- 万能方法：完全脱离文档流，然后margin:auto;
    position:fixed;
    left:0;right:0;
    top:0;bottom:0;
    margin:auto;

### stikey 粘性定位（新的方法）
- relative和fixed的结合---吸顶效果
```html
 <style>
        *{
            margin:0;
            padding:0;
        }
        .box1{
            width:1000px;
            margin:0 auto;
            height:40px;
            background:orange;
        }
        .nav{
            width:100%;
            height:80px;
            background:#000;
            position:sticky;
            top:30px;
        }
        .con{
            width:100%;
            height:3000px;
            background:pink;
        }
    </style>

    <div class="box1"></div>
    <div class="nav"></div>
    <div class="con"></div>
```


# 2019-12-17 上午

## 定位 应用

### 实现元素在父元素里左右上下居中
#### 简单方法
- 父元素-relative
- 子元素-absolute; top/right/bottom/left：0; margin:auto;

- 示例
```html
<title>相对定位/绝对定位 结合</title>
    <style>
        .box1{
            width: 500px;
            height: 300px;
            background: teal;

            position: relative;
        }
        .box2{
            width: 100px;
            height: 80px;
            background: tomato;

            position: absolute;
            top: 0;right: 0;
            left: 0;bottom: 0;
            margin: auto;
        }
    </style>

    <div class="box1">
        <div class="box2"></div>
    </div>

```
#### 麻烦方法
- 父元素-relative
- 子元素-absolute; top/left：50%; margin-left: -宽度的一半; margin-top: -高度的一半;

- 示例
```css
        .box2{
            width: 100px;
            height: 80px;
            background: tomato;

            position: absolute;
                                    /*此处做修改：*/
            left: 50%;              
            top: 50%;           /*代码执行到这儿，box2左顶点在box1的中心点*/
            margin-left: -50px;
            margin-top: -44px;      /*再减去宽高的一半，即左移上移自身的一半，是box2和box1的中心点重合，即实现上下左右居中*/
        }
```


### z-index:; 控制定位元素层叠关系
- 控制**定位元素**的层次关系；
- 属性值：数值越大，权重越大
- 可为负数
- 默认值为auto;
#### 示例
```html
<style>
    /* 一定记得清掉 p 标签的默认margin，太为难人了 */
    *{margin: 0;padding: 0;}
    .box{
        width: 226px;
        height: 134px;
        position: relative;
    }
    p{
        width: 226px;
        height: 20px;
        font-size: 16px;
        background: teal;
        line-height: 20px;
        text-align: center;

        position: absolute;
        left: 0;
        bottom:0;
        z-index: 1;
    }
    span{
        width: 20px;
        height: 20px;
        background: tomato;

        position: absolute;
        left: 0;
        bottom: 0;
        z-index: 2;
    }
    </style>

    <div class="box">
        <img src="./images/pic_03.jpg" alt=""马化腾>
        <span>1</span>
        <p>This is 马化腾.</p>
    </div>
```


### **banner**图-子元素超出父元素，实现居中的方法
```html
 <title>子超父-实现居中</title>
    <style>
        *{margin: 0;padding:0;}

        .father{
            width: 500px;
            height: 300px;
            background: teal;
            margin: 0 auto;
            position:relative;
        }
        .con{
            width: 800px;
            height: 200px;
            background: tomato;
            position: absolute;
            left: 50%;
            margin-left: -400px;    /*这种方法跟上面 子元素在父元素里上下左右居中的 麻烦方法 相似*/
        }
    </style>

    <!-- 子元素超出父元素，实现居中的方法 -->
    <div class="father">
        <div class="con"></div>
    </div>
```
#### 图片太长，展示时去掉滚动条
-    **overflow:hidden;** 
```html
    <style>
        #banner{
            height:400px;
            background:#ccc;

            overflow-x:hidden; /*将超出的部分隐藏掉，去掉滚动条*/
        }
    </style>
    
    <div id="banner">
        <div class="banner-con">
            <img src="./images/banner.jpg" alt="">
        </div>
    </div>
```


## 轮播图
- 不是图片的滚动，是一个元素发生的平移
- 横向区域动态设置长度，为所有图片的长度和
- 结构很重要
### 超宽轮播图
- 样式（只展示必须要有的）
```css
        .img-show{
            position: relative;
            /*给span当爹，相对定位*/
        }
        .img-show span{
            display: block;
            width: 30px;
            height: 60px;

            cursor: pointer; /* 鼠标-》手型 */

            position: absolute;
            top: 170px;
        }
        .pre{left:20px;}
        .next{right: 20px;} /*上面已经加了绝对定位*/

        .img_box{
            width: 3000px;/*包含三张图片的总长度*/
            height: ;
            /* 给imgBox添加定位的原因：控制左右移动 */
            position:absolute;
            left:0;
        }
        .img_box img{
            float: left;
            width: 1000px;
            height: 400px;
        }
```
- 结构
```html
    <div class="img-show">
        <div class="img_box">
            <img src="https://img.zcool.cn/community/014fed57f4701ea84a0d304f1b79fb.jpg@1280w_1l_2o_100sh.jpg" alt="">
            <img src="https://img.zcool.cn/community/0109f2578883a70000018c1b5aaea8.JPG@1280w_1l_2o_100sh.jpg" alt="">
            <img src="https://img.zcool.cn/community/0118cf5837d75ea801219c77f35e67.jpg" alt="">
        </div>
        <span class="pre"><</span>
        <span class="next">></span>
    </div>
```
### 鼠标->手型
cursor: pointer;

### 圆角属性 
border-radius: 10px; （写入半径值）
radius 半径
- 示例 /*是放在banner图下的 小圆点*/
```html
<style>
.banner-con ol{
            width:200px;
            height:20px;
            position:absolute;
            right:100px;
            bottom:10px;
        }
        .banner-con ol li{
            float:left;
            width:20px;
            height:20px;
            background:gray;
            margin:0 3px;
            /* 圆角属性 */
            border-radius: 10px;
            cursor: pointer;
        }
        .banner-con ol .active{   //等js添加事件什么的
            background:blueviolet
        }
    </style>
</head>
<body>
    <!-- 点 -->
    <ol>
        <li class="active"></li>
        <li></li>
        <li></li>
    </ol>
```

## 选项卡
- 示例
```css  (关键代码，以后要添加时事件来触发)

    .btnBox .active{
        background:purple；
    
    .conShow  .tabShow{
        display:block;
    }
```
```html
    <div class="btnBox">
        <span class="active">btn1</span>
        <span>btn2</span>
        <span>btn3</span>
    </div>
    <div class="conShow">
        <div class="tabShow">tab1</div>
        <div>tab2</div>
        <div>tab3</div>
    </div>
```





## 二级菜单
- 二次菜单占据空间，解决办法：
    （1）给li固定宽高（依旧占据空间，不用）（不过试过之后，发现虽然占空间，但不影响排版，**待以后经验**）

    （2）做定位（经常使用，相对/绝对定位配合，相对占据空间，绝对不占据）
所以，二级菜单必须用定位做，使之不占空间

- 示例
```html
/* 二级菜单 - 浮动 定位 元素类型转换 */
<style>
        *{margin: 0;padding: 0;}
        ul,ol,li{list-style: none;}
        a,u{text-decoration: none;}
        .nav1{
            width: 408px;
            height: 30px;
            margin: 50px auto;
            /* padding-left: 0;s */
        }
        .nav1 li{/* li此处是占据空间的，不用担心二次菜单的li把它覆盖掉 */
            float: left;
            
            position: relative; /*确定参考物*/
        }
        .nav1 li a{
            display: block;
            width: 100px;
            height: 30px;
            line-height: 30px;
            margin: 0 1px;
            text-align: center;
            font-size: 16px;
            color: #ccc;
            background: #3b3b43;
        }
        .nav1 li a:hover{
            background: #000;
            color: #fff;
        }
        .nav1 li .nav2{
            position: absolute; /*不占据空间*/
            display: none;
        }
        .nav1 li:hover .nav2{
            display: block;
        }
    </style>


    <!-- 二级菜单 -->
    <ul class="nav1">
        <li>
            <a href="#">首页</a>
        </li>           
        <li>
            <a href="#">新闻</a>
            <ul class="nav2">
                <li>
                    <a href="#">new</a>
                </li>
                <li>
                    <a href="#">new</a>
                </li>
            </ul>
        </li>           
        <li>
            <a href="#">案例</a>
            <ul class="nav2">
                <li>
                    <a href="#">case</a>
                </li>
                <li>
                    <a href="#">case</a>
                </li>
                <li>
                    <a href="#">case</a>
                </li>
            </ul>
        </li>           
        <li>
            <a href="#">关于</a>
            <ul class="nav2">
                <li>
                    <a href="#">about</a>
                </li>
                <li>
                    <a href="#">about</a>
                </li>
                <li>
                    <a href="#">about</a>
                </li>
            </ul>
        </li>           
    </ul>
```

## 楼层效果**锚点**
- id选择符 和 <a href="#"></a>合作使用
- 插件 fullpage


# 2019-12-17 下午

## PC宽高自适应
**宽高**根据内容进行变化

### 宽度 自适应
块状元素，不设置宽度 or width:100%; 宽度随父元素进行改变。

### 高度 自适应
- 第一种  不设置height or height:auto; 表示当前元素的高，是被内容撑开的。
- 第二种  子元素适应父元素（必须保证父元素有高度）

    元素和浏览器窗口等宽等高（移动端整屏 body，html基本都是这样100%的设置）
    前提： body,html{width:100%;height:100%;} 保证文档的宽高
#### min-height:; 最小高度
- 需求：
        当内容量比较多，内容撑开容器大小；
        当内容量比较少，让容器保持一个最小高度。
**对于高版本浏览器来说，此时，将height->min-heigh即可**
- 注意：
        只要有一个版块设置了min-height，外层元素也要设置。

- IE低版本(IE6)，learn解题思路
```txt
如果考虑兼容：
  (1)IE6不能识别 min-height,但是ie6认为 height 就是最小高度。
  (2)非IE6浏览器 能识别 min-height  如果存在height 则高度固定。（注意：min-height和height不是一个属性）

分析：不让非IE6识别height ,只让IE6识别height

方法：
  (1) 选择符{_height:300px;min-height:300px;}
  (2) 选择符{min-height:300px;height:auto!important;height:300px;}
```
##### 过滤器（解决兼容问题）
- 下划线过滤器  （ IE6过滤器 ）
    _属性：属性值；

- !important  ( IE6不识别 )
    属性：属性值!important;（不算过滤器，但都当过滤器用）

- *属性过滤器
      当在一个属性前面增加了*后，该属性只能被IE7浏览器识别，其它浏览器忽略该属性的作用。

     语法：选择符{*属性：属性值；}

- \9  ：IE版本识别；其它浏览器都不识别

     语法：选择符{属性：属性值\9;}

- \0  : IE8 及以上版本识别；其它浏览器都不识别

    

## 高度塌陷
- 出现的场景：子元素有浮动，父元素没设置高度

- 解决：
    + 方法 1：给高度塌陷的元素添加overflow：hidden;

        + 原理：因为overflow:hidden 触发了 BFC；在BFC规定，计算BFC高度的时候，浮动元素也参与计算；
        （既然如此，那么只要是能够出发BFC的元素就都可以用了，不过考虑到布局，依然是overflow用的最多）

        + 弊端：会隐藏掉定位在当前元素之外的内容。
        
    + 方法 2：在浮动元素下面添加一个空的div   并且给div{clear:both;}

        + 原理：添加clear:both  忽略上面浮动元素所预留出来的空间。(闭合浮动，闭合空间)

        + 弊端：代码冗余

    + 方法 3：万能清除法
```css
        选择符::after{
            content:" ";/*随便田个啥，不加也行，不加的话visibility也可以不加，但是说不定*/
            display:block;
            height:0;
            overflow:hidden;
            clear:both;
            visibility:hidden;
        }

        选择符{
            zoom:1;/*给IE浏览器兼容加的，zoom有很多用法*/
        }
```
- 示例
```html
    <style>
        *{margin:0; padding:0; }
        .clear_fix::after{
            content:".";
            display:block;
            height:0;
            overflow: hidden;
            clear:both;
            visibility: hidden;
        }
        .clear_fix{zoom:1}

        .box{
            width:800px;
            background:#ccc;
            margin:50px auto;
        }
        .left{
            width:200px;
            height:200px;
            background:orange;
            float:left;
        }
        .right{
            width:200px;
            min-height:300px;
            background:blue;
            float:left;
        }

    </style>

    <div class="box clear_fix">
        <div class="left"></div>
        <div class="right">
            一大堆内容
        </div>
    </div>
```




# 面试题：visibility:hidden;与display:none的区别？
- 都能隐藏空间、但前者保留元素且占据空间
- （看Word文档）


# 2019-12-18 上午

# 全屏页面-高度自适应应用
- 按百分比划分版块，使之总体100%，占据全屏
- 图片要去掉默认样式，然后设置为宽高100%
- 全屏页面，不涉及二级菜单，则导航可用<p><a>p嵌套a即可</a></p>（控制一行文本比控制一个元素容易的多）
- 实现文字上下居中，此处用定位（如top-40%用百分比形式）
    + 相对定位占据文档流，相对自身移动
    + 使用绝对定位的话，记得p{width:100%；}(因为你加了绝对定位，完全脱离文档流，p不会继承父元素的高度)

#### 示例
- css样式
```css
    *{margin: 0;padding: 0;}
    a,u{text-decoration: none;}
    img{
        border: 0; /*去除IE低版本浏览器蓝色边框*/
        display:block;/*消除图片间距问题*/
    }

    body,html{height: 100%;font-size: 12px;}/*全屏*/
/* banner */
    .banner{height: 84.47%;}
    .banner img{height: 100%;width: 100%;}/*填满*/

/* 第一种，相对定位 */  /*中间部分*/
    .nav{height: 10.68%;}
    .nav p{
        text-align: center;
        position: relative;/*加的是相对定位，相对于自己定位*/
        top: 40%;
    }
    .nav a{
        padding: 0 1%;/*最好用百分比显示，毕竟全文都是百分比表示的*//*除以父元素的宽度，宽度自适应*/
    }

/* 第二种，绝对定位 */  /*底部*/
    .bottom{height: 4.85%;background: teal;position:relative;}
    .bottom p{
        text-align: center;
        width:100%;/*绝对定位，完全脱离文档流，内容范围不是100%，必须加宽度*/
        position: absolute;
        top: 30%;
    }
```
-结构
```html
    <div class="banner">
        <img src="./images/banner_01.jpg" alt="">
    </div>
    <div class="nav">
        <p>
            <a href="#">首页</a>
            <a href="#">首页你好</a>
            <a href="#">首页你好</a>
        </p>
    </div>
    <div class="bottom">
        <p>版权所有。。。。。。。。。。。。版权所有。</p>
    </div>
```


# 控制位置-方法
- 浮动
- 盒模型
- 定位 （调整位置关系时）


# 图片整合-雪碧图
- 缓解服务器的压力
- 降低图片体积，提高加载速度

- 使用
    + 图片定位 background-position:;

- 规则
    + 根据项目需求，每个小图标之间留出足够的间距
    + 整合的图片的背景必须是透明-格式.png！
    + 尽量上下排列（跟UI设计师沟通）

- 示例  task7-雪碧图-腾讯课堂nav.html



# 可能是面试题

## 浏览器内核（核心源码）
- 四大内核
    - Trident : IE
    - Gecko : Mozilla（火狐-前身是网景）
    - Webkit : 苹果&谷歌旧版本
    - Blink : 谷歌&欧鹏
- 已弃用
    - Presto：（Opera前内核，已弃用）

- 详情看“6-兼容&图片整合.md”文档

## 苹果
- Safari
    + Safari是苹果计算机的操作系统macOS中的浏览器，使用了KDE的KHTML作为浏览器的运算核心。
    + Safari也是iPhone手机、iPod Touch、iPad平板电脑中iOS指定默认浏览器。
- Mac OS 与 iOS 的区别
    + 苹果的Mac OS是传统的计算机操作系统属于Unix。
    + iOS是从MacOS衍生出来的专门未为移动设备(iphone)推出的操作系统。
    + iOS和Mac OS的UI观念有很大差别，iOS主要支持手势操作，包括多触点技术等等。
    + 从开发人员观点看，iOS和macos相比，对普通开发人员多加了不少限制。



## 名词
- bug
- hack （解决方法）
- filter （过滤器）

- 详情看“6-兼容&图片整合.md”文档

### 各种bug
#### IE bug
- 图片有边框BUG、图片间隙、双倍浮向（双倍边距）（只有IE6出现）、默认高度（IE6、IE7）
- 详情看“6-兼容&图片整合.md”文档

#### 非IE bug（重点）



- 1、表单元素行高对齐不一致

    + 描述：表单元素行高对齐方式不一致
    + hack:给表单元素添加声明：float:left;


- 2、按钮元素默认大小不一

    + 描述：各浏览器中按钮元素大小不一致
    + hack1： 统一大小/（非表单里面的按钮，按钮元素用a标记模拟，而不是input标签；或者说，只有form表单才会用input按钮显示）
    + hack2: input外边套一个标签（比如span），在这个标签里写按钮的样式，把input的边框去掉。
    + hack3:如果这个按钮是一个图片，直接把图片作为按钮的背景图即可。


- 3、鼠标指针bug
    + 描述：cursor属性的hand属性值只有IE9以下浏览器识别，其它浏览器不识别该声明，cursor属性的pointer属性值IE6.0以上版本及其它内核浏览器都识别该声明。所以用 **cursor:pointer;**
        - hack: 如统一某元素鼠标指针形状为手型，应添加声明：cursor:pointer
    + 其他属性值：
        - cursor:         ;
        - auto默认
        - crosshair加号
        - text文本
        - wait等待
        - help帮助
        - progress过程
        - inherit继承
        - move移动
        - ne-resize向上或向右移动
        - pointer手形


- 4、透明属性
    + 兼容其他浏览器写法：opacity:value;(value的取值范围0-1; 例：opacity:0.5;)
    + IE浏览器写法：filter:alpha(opacity=value);取值范围 1-100(整数)

- 5、 margin常见bug
	+ a: 上下相邻的两个元素上下之间的margin值不会叠加，按最大值设置；
	+ b: margin-top 当父元素 和 第一个 子元素 都没有浮动情况下，margin-top会把父元素也带下来；
	+ c：margin-left/right 使用一般没什么问题，但margin-top/bottom要视情况而定；



# 2019-12-18 下午

## 独立渲染区BFC
- BFC---盒子的生存法则（我起的名儿）
```txt
BFC(Block formatting context)直译为“块级格式化上下文”。它是一个独立的渲染区域，只有Block-level box（块）参与， 它规定了内部的Block-level Box如何布局，并且与这个区域外部毫不相干。
```

### BFC的布局规则

- 内部的Box上下排列。

- Box垂直方向的距离由margin决定。（BFC解决margin上下重叠问题）
    + **属于同一个BFC**的两个相邻Box的margin会发生重叠 
    + 解决：使之不同属于一个BFC---外面套个盒子并使这个盒子触发BFC

- BFC的区域不会与float box重叠。（两栏、三栏布局，双飞翼布局）

- 计算BFC的高度时，浮动元素也参与计算（清除内部浮动、BFC解决高度塌陷）

- 每个元素的margin box的左边， 与包含块border box的左边相接触

- BFC---页面上的一个隔离的独立容器，容器里面的子元素不会影响到外面的元素。



### 触发BFC的元素、属性

- 根元素(html)
- 设置float
- position为absolute或fixed
- display为inline-block, table-cell, table-caption, flex, inline-flex
- overflow不为visible----**overflow:hidden;**(常用)


### BFC的应用  (对应示例请看 task7)

- BFC实现自适应**两栏、多栏**布局
    + 借助BFC---BFC的区域不会与float box重叠。（加overlow：hidden；）

- BFC实现双飞翼布局 
    + 第二栏---要放在中间 的盒子---**不设置宽度  结构排在最后面**
    + 设置**overflow:hidden；**触发BFC

- 清除内部浮动

- BFC解决margin上下重叠问题

- BFC解决高度塌陷

#### 两栏/三栏布局
- 借助BFC
    + 第三栏---排在最后的盒子---**不设置宽度**
    + 设置**overflow:hidden；**触发BFC

- 双飞翼布局---css盒子模型里padding来实现（原汁原味儿）
    + 第二栏---要放在中间 的盒子---**不设置宽度  结构排在最后面**，可以实现在浮动元素之下（浮动元素形成了float box）
    + 外包一个盒子如div，给此div设置padding

- css3提供了一个功能函数，可计算页面剩余宽度，float就管用了
    width:calc(100%-已有元素长度像素)；
    （但由于版本兼容问题，基本不用）


## 布局方式（暂时不全）
- 流式布局 --- 自上而下，自适应布局
- 双飞翼布局（两边固定，中间自适应；与三栏布局还是不同的；三栏布局是随便三栏）
    + 利用BFC实现双飞翼布局
    + 利用padding实现双飞翼布局
- 响应式布局
- css3功能函数实现布局

## iframe 标签
- 文档中的文档，把其他网页嵌入进当前页面；
- 用的比较多的地方是后台管理系统
- 能不用则不用，性能消耗大


## 媒体查询（了解）
- 监测设备的变化
- 示例 day8  
（响应式开发的原理，虽然这个布局不怎么用了，但这个方法还是会用到的）
