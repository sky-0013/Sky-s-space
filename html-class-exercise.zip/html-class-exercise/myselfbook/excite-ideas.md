### table表格
```css
(1) 给单元格去掉边框，但是保持table边框存在
<table></table> 的 border:1;
<td></td> 的 {border-style:none};    (注意：此处属性值为0则不起作用)
即可实现，详情请看table1.html的第5个table示例。
```

### form表单
```html
(1)分组表单
表单字段集标签 fieldset 与 字段级标题标签 legend 先确定好分组，然后将其他元素放到 p 标签里面，如下：
        <form action="">
		<fieldset>
			<legend>个人信息</legend>
			<p>
				<label for="">姓名*</label>
				<input type="text">
			</p>			
		</fieldset>
		<fieldset>
			<legend>其他信息</legend>
		</fieldset>
    </form>
(2)textarea多行文本域 设置不能拖动时，
一定要注意，{resize:none;}是 css 属性！

(3)input框、按钮时候，尽量外层给套一个盒子，比如标签span等,因为浏览器版本问题，有的会border算在盒子里面，而不是像其他标签一样放在外面贴着。

(4) select 只在表单里面使用
```

### border边框问题
```css
(1)border-style:solid none none none;可以控制元素 上、右、下、左 的边框存不存在；
(2)border-style 这个属性的属性值不能用0；
(3)border:0; == border:none;  border属性是可以用0的；
```

### 鼠标滑过父元素改变子元素的状态 (还不能通过子元素改变父元素)
```html
(1)处理css样式时，包含选择器，父元素:hover在外，子元素在内，如下：
<style>
		.box{
				width:500px;
				height:300px;
				background:red;
		}
		.con{
				width:200px;
				height:100px;
				background:pink;
		}	
		.box:hover .con{ /*一定要注意，顺序不能变*/
				background:blue;
		}
</style>
<body>
		<div calss="box">
				<div class="con"></div>
		</div>
</body>
```

### margin常见的bug
```txt
			a:当父元素和子元素都没有浮动的情况下：给第一个子元素加margin-top，会错误的把margin值加在父元素上面；
			b:相邻两个元素上下margin会重叠，按照较大的值设置；
```

### 相对路径注意
```txt
	（1）当前路径注意加上 ./  比如： ./images/cat.jpg  ;
```

### 浮动最高位置问题
```html
(1)/* 浮动时，如果该元素上面有占空间的元素，则浮动最高处就是占用空间的元素底部。 */
	<style>
        .out{width:200px;height:200px;background: burlywood;}
        .in1{width:50px;height:50px;background: brown;}
        .in2{width:100px;height:100px;background: chartreuse;float:left;}    
        .in3{width:150px;height:30px;background:cornflowerblue;}
	 </style>
	 
	 <div class="out">
        <div class="in1"></div>
        <div class="in2"></div>
        <div class="in3"></div>
	</div>
(2) 浮动时必须设置宽、高（亲自试验所得）；
```

### 浮动相关问题
```txt
(3) 给所有元素加上浮动，都能设置宽、高；

(4) 浮动的元素外面必须包一层父元素，且父元素必须设置高度
```

### 表格的相关问题
```html
(1) table-layout: fixed;
	可以固定 宽度 不随着内容的改变而改变，但不能 固定高度（高度还是会随着内容进行更改，单词还好，句子就不行了，亲测有效）
```

### 盒模型相关问题
(1) padding是添加在盒子上面的（不是添加在内容上面的）;
(2) margin常见bug
	a: 上下相邻的两个元素上下之间的margin值不会叠加，按最大值设置；
	b: margin-top 当父元素 和 第一个 子元素 都没有浮动情况下，margin-top会把父元素也带下来；
  - 示例：（在不清除全体元素 margin padding 的情况下，p标签是有自己的样式的）
  ```html
	<style>
        .hezi{
            width: 500px;
            height: 300px;
            background: teal;
        }
        .zi{
            width: 200px;
            height: 100px;
            background: tomato;
        }
	</style>

	 <div class="hezi">
        <div class="zi">
            <p>我等会观看咖喱饭吗</p>
        </div>
	</div>
	PS：这种情况下，p标签有默认margin-top值的，而且p标签作为一个子元素，没有浮动，那么父元素也会跟随p标签同时下移。

	<style>
        .hezi{
            width: 500px;
            height: 300px;
            background: teal;
        }
        .zi{
            width: 200px;
            height: 100px;
            background: tomato;
        }
		.zi2{
            width: 200px;
            height: 100px;
            background: yellow;
        }
	</style>

	 <div class="hezi">
        <div class="zi2"></div>
        <div class="zi">
            <p>我等会观看咖喱饭吗</p>
        </div>
	</div>
	PS：此时p标签是第二个子元素，会与第一个子元素之间产生距离。
```
(3) margin:0 auto; 只使适用于“块状元素”！！！！！
```


### 文字误差问题
```html
(1) font-size:value; 与 line-height:value; 相结合使用，可以减少因为标签带来的高度误差；
```

## 写项目需注意问题

### 文档结构
```html
(1) 站点至少要有文件夹css、images、js 和 一个首页index.html；
(2) css样式至少要有三个，如下：
	+存放所有网页相同的样式（比如logo、导航、底部信息） 
		<link rel="stylesheet" href="./css/common.css">
	+存放所属网页的样式（如存放大首页的样式）
		<link rel="stylesheet" href="./css/index.css">
	+重置的样式，将元素默认样式都清除
  		<link rel="stylesheet" href="./css/reset.css">
```

### 重置样式（清除默认样式）
```css

@charset 'utf-8';

html,body,ol,ul,li,h1,h2,h3,h4,h5,h6,p,th,td,dl,dd,form,fieldset,legend,input,textarea,select{margin:0;padding:0;}
body{font-family:"微软雅黑";}
b,strong{font-weight:normal;}
i,em{font-style:normal;}
ul,ol,li{list-style:none;}
a,u{text-decoration:none;}
h1,h2,h3,h4,h5,h6{font-size:16px;font-weight:normal;}	
img{border:0;display:block}
input,fieldset{outline: none;border:0;}
.clear_fix::after{content: " ";clear: both;display:block;height: 0;overflow: hidden;visibility: hidden;}
.clear_fix{zoom:1;}

```

### 相同样式放在公共区域，有不同的则视情况重置（有同样样式可以快速修改，提高整体的维护性）

### 图片 & img 标签问题
- 在一般情况下，可以在父元素里面使用text-align:center;居中，但是之后不怎么会用它的默认样式，因为会因为某些原因而改变它的display类型；
- img标签 
	+ img设置宽度 最好将之转化为 block；加边框的话，外边套盒子，当然盒子也要设置宽高；

### 虽然p、h2等标签样式重置了，但是还是要设置line-height来清一下清不掉默认的字体上下间距（可自己尝试一下）

### 导航条
```html
	1、无序列表ul
	2、
		<ul>
			<li>
				<a href=""></a>  <!--给a标签加上浮动，可以设置宽、高；-->
			</li>
			<li>
				<a href=""></a>  <!--给a标签加上浮动，可以设置宽、高；-->
			</li>
		</ul>
	3、li添加浮动（ul、li都不用添加宽高）
	4、a 添加样式，添加浮动(或者设置 display:block;)，可设置宽高 （但a一定要加 高度，宽度可以随字体大小确定，保证体验度）
	5、调整文本
	6、调细节
	
	示例1：
	--- 设置：ul-右浮动、li-左浮动、a-左or右浮动 高 字体样式
	<style>
		.top-con{width: 1012px;margin: 0 auto;}

		/* top logo nav 设置：ul-宽、li-浮动、a-浮动 高 字体样式*/
		#top{background: #232323;}
		.top-con{height: 62px;}
		.top-con h1{padding:11px 0 0 12px;float: left;}
		.top-con ul{float: right;} 
		/*首页左侧的padding-left:15;别忘了加上,所以是789*/
		.top-con ul li{float: left;}

		+ ul 、li 都没有设置高度，却没有高度塌陷分析如下：
		+ 不发生高度塌陷的前提：父元素包着浮动元素、父元素有高度
		+ 这里没有高度塌陷原因：a 浮动了，li 套着 a ；
							  li 浮动了，ul 套着 li ；
							  ul 浮动了，.top-con 套着 ul；
							  .top-con 有高度；
		  所以并不违背该前提。
		  而且，浮动元素可以设置高度。
		
		.top-con ul li a{
			height: 62px;
			color: #fff;
			font-size: 14px;
			line-height: 62px;
			background: url(../images/border_03.jpg) no-repeat right center;
			float: left;
			padding:0 15px;
		}
		.top-con .nav_last{background-image: none;}
	</style>
	<!-- top -->
    <div id="top">
        <div class="top-con">
            <h1><a href="#"><img src="./images/1000_03.jpg" alt="logo"></a></h1>
            <ul>
                <li><a class="nav_two" href="#">首页</a></li>
                <li><a class="nav_two" href="#">课程</a></li>
                <li><a href="#">走进千峰</a></li>
                <li><a href="#">双选会</a></li>
                <li><a href="#">走进千峰</a></li>
                <li><a href="#">走进千峰</a></li>
                <li><a href="#">走进千峰</a></li>
                <li><a class="nav_eng" href="#">APP外包</a></li>
                <li><a href="#">走进千峰</a></li>
                <li><a class="nav_last" href="#">走进千峰</a></li>
            </ul>
        </div>
	</div>
	
	示例2：
	---ul、li-左浮动、a-左or右浮动 高 字体样式 #nav-初代父元素 高度（一定要有高度，不然会发生高度塌陷）
	
	<style>
		#nav{height: 58px;background: #323232;}
		#nav .nav-con{padding-left: 27px;width: 975px;}

		+ 注意：这儿的width要加上，不然盒子宽度增加，又是左右居中，整体会左移
		+ 因为初代父元素 #nav 有高度,所以不会发生高度塌陷，但是浮动的父元素时一定要有高度的

		#nav .nav-con li{float: left;}
		#nav .nav-con li a{float: left;width: 119px;height: 58px;color: #fff;font-size: 12px;line-height: 58px;text-align: center;border-right:1px solid #4a4a4a;}

		+ ul 、li 都没有设置高度，却没有高度塌陷分析如下：
		+ 不发生高度塌陷的前提：父元素包着浮动元素、父元素有高度
		+ 这里没有高度塌陷原因：a 浮动了，li 套着 a ；
							  li 浮动了，ul 套着 li ；
							  ul 没有添加浮动 高度为0，但 #nav 套着 ul；
							  #nav 有高度；
		  所以并不违背该前提。

		#nav .nav-con .border0{border-right: 0;}
		
	</style>
	 <!-- nav -->
    <div id="nav">
        <ul class="nav-con">
            <li><a href="#">集团介绍</a></li>
            <li><a href="#">集团介绍</a></li>
            <li><a href="#">集团介绍</a></li>
            <li><a href="#">集团介绍</a></li>
            <li><a href="#">集团介绍</a></li>
            <li><a href="#">集团介绍</a></li>
            <li><a href="#">集团介绍</a></li>
            <li><a class="border0" href="#">集团介绍</a></li>
        </ul>
    </div>
```

### 新闻列表
```html
1、如果有时间html结构必须：
	<li>
		<a href="#">新闻新闻新闻内容</a>
		<span>2019-03-04</span>
	</li>
2、给 li 添加 宽 高（量行高）；
3、调整文本样式（文本大小、文本颜色......）
4、如果有时间，给 a 和 span 添加一左一右浮动；
5、用背景图的形式给li添加列表符号（调整背景图的位置，上下居中background:颜色 url left center;） ；
6、然后再用line-height让文本上下居中 ；
7、给li添加padding-left 把背景图（项目符号）露出；
```
#### 新闻列表-自己总结( a-color、li-宽高 行高 项目符号背景 字体大小 padding-left)
- 新闻条右侧没有时间，采用 ul>li>a（> 代表包含）
- 新闻条右侧有时间显示，采用以下格式：
	<ul>	
		<li>
			<a href="#">新闻新闻新闻内容</a>
			<span>2019-03-04</span>
		</li>
	</ul>
- 一条新闻是一个li，设置li的宽、高（a、span是行内元素，不支持宽、高；li高度量取行高）
- a、span一左一右浮动，设置字体颜色、大小
- 添加项目符号，当做背景图url给li加上，保持左中
- li设置文本上下居中line-height==height
- li设置padding-left，将项目符号露出来，相应减去li宽度

### 对于版块case内容来说
```txt
(1) 盒子能不加宽高尽量不加，靠内容撑开
(2) 除非用了浮动，不得不加父元素，且父元素必须加高度
(3) dl dt dd ; dt 里面如果是图片，尽量还是用img吧，图片设置成 宽高100%，
  + img{width:100%;height:100%;}继承父元素 
```

### a标签的问题
```txt
(1) a标签有默认样式，两个a并列展示会有空格，解决方法：
	- 第一种：a放一行
	- 第二种：a加浮动
```

## 文本溢出

```css
(1) overflow  溢出属性（设置滚动条）
    overflow:scroll/auto/hidden/visible（默认）/inherit;

    overflow-x:hidden;   支持x轴
    overflow-y:hidden;   支持y轴

(2) white-space:属性值; 空白区域处理

		normal：默认值，多余空白会被浏览器忽略只保留一个；
		pre：空白会被浏览器保留；
		pre-wrap：保留一部分空白符序列，但是正常的进行换行；
		pre-line:合并空白符序列，但是保留换行符；
		nowrap:文本不会换行，文本会在同一行上继续，直到遇到<br/>标签为止;

(3) text-overflow:clip/ellipsis（省略号）;
		clip：不显示省略号（...），只是简单的裁切;
		ellipsis：当对象内文本溢出时，显示省略标记；

(4) **单行**文本溢出省略号显示
	+ 容器有宽度
	+ overflow:hidden;
	+ white-space:nowrap;
	+ text-voerlow:ellipsis;

(5) **多行**文本的设置（不常用）
	- 与后台沟通，限制字符，前端在最后加上“...”
	- 用伪选择器 ：：after{content:"...";}，得定位到文字最后
	- 用css3属性渐变，添加遮罩

```

## :hover
- 添加样式的时候，**只能**改变**自身或子元素**的样式，
- **不能**通过子元素改变**父元素和同级元素**的样式。

## 版块布局 
- 优先使用**盒模型**和**浮动**（PC端）；
- 发生层叠，用**定位**（少用）；

## 高度自适应问题
- 网页编写都要加高度自适应
- banner除外
- 只要有一个版块设置了min-height，外层元素也要设置
- 简记：除banner的height外，其他全部改成min-height

## 透明度设置方法
- css3  rgba模式 
	+ rgba(0,255,204,0.5);(最后一表示透明度,用英文alpha代表)
	+ 背景颜色透明，文字正常显示；

- 颜色属性值 transparent 代替颜色值 为 “透明”；
	+ eg：background：transparent;背景就透明了；

- opacity
	+ 背景、文字都变透明
	+ 兼容其他浏览器写法：opacity:value;
		(value的取值范围0-1; 例：opacity:0.5;，可简写为“.5”)
	+ IE浏览器写法：filter:alpha(opacity=value);取值范围 1-100(整数)


## 垂直居中问题
- 文字垂直居中 line-height:; 行高
- 元素垂直居中 vertical-align:; 找中线
- 定位

## 水平居中问题
- 文字水平居中 text-align：center;
- 元素水平 margin:0 auto;
- 定位

## img 默认问题
- img{border:0; display:block;}
	+ 解决IE低版本，当图片有超链接时，会存在蓝色边框；
	+ 后者因为img内联元素，默认间距，得去掉；

## 注意一个点 ： 非表单里面的按钮，都用a标签去模拟


# 2019-12-19

## 多个div边框重叠问题
- 可参考 “task8练手速网页图”
```html
<title>多个div边框重叠问题</title>  
    <style>
        div{
            width: 300px;
            height: 300px;
            background: teal;
            border: 5px solid red;
            float: left;

            margin: 0 -5px -5px 0;
			/*当前元素右边/下边margin分别左移/上移一个边框的宽度；相当于右边的元素向左移一个边框的距离，即   
			margin：0 0 -borderwidth -borderwidth  （borderwidth即为边框的宽度）*/
        }
    </style>

    <div></div>
	<div></div>
```

## 绝对定位与margin-top
- 如果父元素的第一个元素用了绝对定位，即便完全脱离文档流，第二个子元素依然可以正常使用margin-top

## 圆角属性
- border-radius: 5px 5px 0 0; /*上 右 下 左*/

## div 最多嵌套4层（实测有效）
- 在用div包img的时候出现了问题
- 以后还是用p标签来包img吧

## 行高 line-height 不算高度
- 比如p标签，如果p标签里没有内容，也没有设置高度，只有line-height是不能把p标签撑开的。


## 取消 inline-block 空白间隙的几种方法
- 将inline-block元素写在一行
- 不闭合双标签
- 让垂直间隙消失，就在子元素上加vertical-align:bottom; (对准那第四条线)
	+ 但子标签内加上任意文字，则display:inline-block元素不会生成垂直方向有空白！

- 让水平间隙消失就是在父级上加font-size:0;然后子元素一定要设置相应自字号（我推荐自己使用）
```css
	.demo {font-size: 0;}
    .demo span{
         background:#ddd;
         display: inline-block;
         font-size: 14px; /*要设置相应的字号*/
    }
```
```html
	<div class="demo">
        <span>我是一个span
        <span>我是一个span
        <span>我是一个span
        <span>我是一个span</span>
    </div>
```
#### inline与inline-block引起的空白间距的问题
- 产生原因：回车--->空白间隔
- 目前解决方法：三种
    + 第一种：将相关标签写在一行，消除换行符
    + 第二种：加浮动，使之转化成为block元素（可能会影响页面布局）
    + 第三种：直接改变元素类型---display:block;


## 清除默认样式（ 重置样式  css reset ）
```txt

	@charset 'utf-8';

	html,body,ol,ul,li,h1,h2,h3,h4,h5,h6,p,th,td,dl,dd,form,fieldset,legend,input,textarea,select{margin:0;padding:0;}
	body{font-family:"微软雅黑";}
	b,strong{font-weight:normal;}
	i,em{font-style:normal;}
	ul,ol,li{list-style:none;}
	a,u{text-decoration:none;}
	h1,h2,h3,h4,h5,h6{font-size:16px;font-weight:normal;}	
	img{border:0;display:block}
	input,fieldset{outline: none;border:0;}
	.clear_fix::after{content: " ";clear: both;display:block;height: 0;overflow: hidden;visibility: hidden;}
	.clear_fix{zoom:1;}

```
- 注意
- img{border:0;}
	+ （解决IE低版本，当图片有超链接时，会存在蓝色边框；）
- img{border:0;display:block;}
	+ （可以等后面元素用到display:inline;的时候，再换回来）
	+ （后者display:block;因为img内联元素，默认间距，得去掉，但是他有一个bug，
		因为img本来是inline类型元素，但她却可以有inline-block的用法，而且，img是inline类型的时候，可以跟随文本一起使用text-align:center;这条居中属性）

### inline 或 inline-block 
- 二者可以使用 text-align 属性，与文字一样可以实现水平居中效果
- img默认是inline，但它却有inline-block的功能，可以与文字一样使用text-align居中效果，但如果变成display：block；就用不了了，


# 2019-12-20

## .clear_fix:after{...}万能清浮动
- 然后直接把clear_fix加入到相应class里就OK
- 为了兼容IE，注意再加上 **.clear_fix{zoom:1;}**


## 阴影box-shadow 与 position的好玩之处
- position:relative;
  box-shadow: 0px 0px 10px #464646;
- 在当前盒子的层叠顺序靠下时，
- 我发现这两条代码合着使用可以制造出阴影效果。

- 可能是因为：
	+ 单独加box-shadow，哪怕是从上而下布局，如果是靠前的元素，加了阴影的效果也会被下面的元素遮住
	+ 再给当前元素添加position：relative;使盒子发生相对定位，但不给位移量，
	+ 盒子还在原处，但是层叠顺序已经靠前了。