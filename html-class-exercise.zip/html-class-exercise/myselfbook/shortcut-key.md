## markdown 文件的常用语法
```txt
(1) h1-h6 为 # 的个数 ， 其中 h1、h2 带下划线；
(2) html页面  "   ```html    ```  "
(3) css页面   "   ```css     ```  "
(4) txt文本   "   ```txt     ```  "   
(4) 加粗 "   **  **   "
(5) 倾斜 "   *    *   "
(6) 项目符号  " - "
 
```

## 快捷键
```txt
VS Code 常用快捷键

0、选中问题
(1)单词单选：
光标放到一个单词上，直接 ctrl+D

(2)多行多选：
上面一行选中某些代码，然后 ctrl+D 可以依次往下选中相应位置的代码，例如(自己试一下)
    <input type="checkbox" name="" disabled><label for="">足球</label>
	<input type="checkbox" name=""><label for="">篮球</label>
	<input type="checkbox" name="" checked><label for="">排球</label>

1、注释：
单行注释：ctrl+/， 注释后再按取消
取消单行注释：alt+shift+A 注释后再按取消

2、移动行
向上移动一行：alt+up
向下移动一行：alt+down

代码整体左移：选中+tab
代码整体右移：选中+ shift+tab

3、显示/隐藏左侧目录栏  
ctrl + b

4、复制当前行
向上复制一行：shift+alt+up

向下复制一行：shift+alt+down
或者
光标末尾，ctrl+c 复制  ctrl+v 粘贴

5、删除当前行
shift + ctrl + k

6、控制台显示隐藏
ctrl + ~

7、查找文件
ctrl + p

8、代码格式化
shift + alt +f

9、新建窗口 
ctrl + shift + n

10、行增加缩进
ctrl + [

11、行减少缩进
ctrl + ]

12、关闭编辑窗口 
ctrl + w

13、关闭所有窗口 
ctrl + k + w 

14、改变编辑器字体大小
ctrl+keyboard plus（加减）改变字体大小 
或 
ctrl+鼠标滚轮

15、一些结合tab键的 生成代码 的巧办法
（1）li*8 按tab，自动生成8行<li></li>

（2）标签大量生成方法：以table为例，tr*5+tab->生成5行，然后选中第一行，Ctrl+d连续选中下面四行，回车，再输入td*3+tab->每个tr里面都有3行td；

（3）标签结合class选择器：div.box-1+tab-> <div class="box-1"></div>

(4) tr*5>td*5 回车会tab  往父元素中嵌套子元素

(5) div{$}*5 可自动生成5个div，然后内容是数字，自动往下

(6) div.case 回车 --->  <div class="case"></div> 其他的选择符也一样
```

### 其他 & PS
```txt
win8切换打开的文档：alt+tab

浏览器刷新：ctrl+r

PS快捷键：F8 出现属性窗口；ctrl+k 单位与标尺；  

alt+s+t 变换选取

alt+c 切换切片工具

alt+v+c 删除切片


```

## VS Code 的常用插件
```txt
1、Auto Rename Tag 修改 html 标签，自动帮你完成尾部闭合标签的同步修改，和 webstorm 一样。

2、Auto Close Tag 自动闭合HTML标签

4、Beautiful 格式化代码的工具

5、Dash Dash是 MacOS 的 API 文档浏览器和代码段管理器

6、Ejs Snippets ejs 代码提示

7、ESLint   检查 javascript 语法错误与提示

8、File Navigator 快速查找文件

9、Git History (git log)   查看 git log

10、Gulp Snippets 写 gulp 时用到，gulp 语法提示。

11、HTML CSS Support 在HTML标签上写class智能提示当前项目所支持的样式

12、HTML Snippets 超级好用且初级的H5代码片段以及提示

13、Debug for Chrome 使用 vs code 来打断点调试

14、Document this Js 的注释模板

15、jQuery Code Snippets jquery 提示工具

16、Html2jade html 模板转 pug 模板

17、JS-CSS-HTML Formatter 格式化

18、Npm intellisense require 时的包提示工具

19、Open in browser 打开默认浏览器

20、One Dark Theme 一个vs code的主题

21、Path Intellisense 自动路径补全、默认不带这个功能

22、Project Manager 多个项目之间快速切换的工具

23、Pug(Jade) snippets pug 语法提示

24、React Components 根据文件名创建反应组件代码。

25、React Native Tools reactNative工具类为React Native项目提供了开发环境。

26、Stylelint   css/sass 代码审查

27、Typings auto installer   安装 vscode 的代码提示依赖库，基于 typtings 的

28、View In Browser  默认浏览器查看HTML文件（快捷键Ctrl+F1可以修改）

29、Vscode-icons  让 vscode 资源目录加上图标、必备

30、VueHelper   Vue2代码段（包括Vue2 api、vue-router2、vuex2）

31、Vue 2 Snippets   vue必备vue代码提示

32、Vue-color   vue 语法高亮主题

33、Auto-Open Markdown Preview markdown 文件自动开启预览

34、EverMonkey 印象笔记

35、atom one dark atom 的一个高亮主题(个人推荐)

```