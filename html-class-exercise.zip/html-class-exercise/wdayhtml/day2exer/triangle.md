##三角形的形成

####注：以下仅为参考，因为天外有天啊...

### 第一步 创建一个只有border的正方形
```html
    <head>
    <style>
        div{
            width:0px;
            height:0px;
            border-top:50px solid #e6d58b;
            border-right:50px solid #000;
            border-bottom:50px solid #ff0000;
            border-left:50px solid #ccc;
        }
    </style>
    </head>
    <body>
        <div></div>
    </body>
```

### 第二步 保留一边
```txt
比如我保留左边灰色区域，相对应把右边border删掉；
```

### 第三步 把平行border透明化
```html
我这边就应该是把上下两条边透明化，代表透明的属性值是transparent；
    <style>
        div{
            width:0px;
            height:0px;
            border-top:50px solid transparent;
            border-bottom:50px solid transparent;
            border-left:50px solid #ccc;
        }
    </style>
然后刷新浏览器，三角形就OK了。
```