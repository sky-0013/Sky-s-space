### 网页的构成：结构（html）、表现(css)、行为(js)

### web标准（标准的集合）

### HTML  汉译（超文本标记语言）   和XHTML的区别

### HTML5的基本结构

### html的基本语法：

    + 单标记、双标记

### 各种常用标签
    + *  超链接
    + *  相对路径

### 列表   ul   ol    dl

### 表格：
    + table   tr   td
    + 数据行分组  ：  thead   tbody  tfoot
    + 数据列分组  ： colgroup
    + 列标题    ：th
    + 表格标题 ： caption
    + 合并单元格：  colspan   rowspan
    + 分割线   ：  rules  添加在table上面

### 表单：
    + form
    + input
        - 类型：
            + text
            + password
            + button
            + submit
            + reset
            + radio
            + checkbox
            + file
    + select 
    + option
    + textarea

    + fieldset
    + legend
    + label


### 表格嵌套表单
    <table>
        <form>
            <tr>
                <td></td>
            </tr>
            <tr>
                <td></td>
            </tr>
            <tr>
                <td></td>
            </tr>
            <tr>
                <td></td>
            </tr>
        </form>
    </table>





### 任务：
    + 任务文件里面的表格、表单
    + 查 post\get

    + 查 ascll码  unicode码
    + 查 markdown 基本语法
    + 整理今天的笔记

